# bebe-dao
A web based DAO voting tool where holders can create 4 type of posts: Proposals, Polls, Issues, Elections and vote on them.

![image](https://babybitcoin.meme/Roadmap.png)
