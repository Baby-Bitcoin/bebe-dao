import {
  addBTN,
  closeBTN,
  addOption,
  removeOption,
} from "./event-listeners.js";

addBTN();
closeBTN();
addOption();
removeOption();
